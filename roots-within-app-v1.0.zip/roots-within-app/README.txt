Roots Within (Philosong app): offline-installable songbook + philosophy reader.
Version 1.0
To add an entry: copy one object in entries[] inside content.js, change id, add mp3 to audio/.
To bump version: change meta.version in content.js (shell cache refreshes; saved songs stay).
All files must stay together in the same folder.
